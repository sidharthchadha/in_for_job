import "./App.css";
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import Home from "./pages/Home";
import CreatePost from "./pages/CreatePost";
import Post from "./pages/Post";
import Registration from "./pages/Registration";
import Login from "./pages/Login";
import PageNotFound from "./pages/PageNotFound";
import logo from './images/InForJob.png';

import { AuthContext } from "./helpers/AuthContext";
import { useState, useEffect } from "react";
import axios from "axios";

function App() {
  const [authState, setAuthState] = useState({
    username: "",
    id: 0,
    status: false,
  });

  useEffect(() => {
    axios
      .get("http://localhost:3001/auth/auth", {
        headers: {
          accessToken: localStorage.getItem("accessToken"),
        },
      })
      .then((response) => {
        if (response.data.error) {
          setAuthState({ ...authState, status: false });
        } else {
          setAuthState({
            username: response.data.username,
            id: response.data.id,
            status: true,
          });
        }
      });
  }, []);

  const logout = () => {
    localStorage.removeItem("accessToken");
    setAuthState({ username: "", id: 0, status: false });
  };
  const myStyle = {
    backgroundImage:
      "url('https://images.unsplash.com/photo-1636955840493-f43a02bfa064?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwcm9maWxlLXBhZ2V8OXx8fGVufDB8fHx8&w=1000&q=80')",
    height: '90vh',
    width: '220vh',
    marginTop: '-150px',
    fontSize: '50px',
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
  };


  return (

    <div className="App">
    
      <AuthContext.Provider value={{ authState, setAuthState }}>
        <Router>
          
          <nav className="navbar bg-light">
           
              <div className="links">
                {!authState.status ? (
                  <>
                    <Link to="/login"> <button class="btn btn-outline-success me-2" type="button">Login</button></Link>
                    <Link to="/registration"> <button class="btn btn-sm btn-outline-secondary" type="button">Registration</button></Link>
                  </>
                ) : (
                  <>
                    <Link to="/"> Home Page</Link>
                    <Link to="/createpost"> Create A Post</Link>
                  </>
                )}
              </div>
              <div className="loggedInContainer">
                <h1>{authState.username} </h1>
                {authState.status && <button onClick={logout}> Logout</button>}
              </div>
          </nav>
          <Switch>
            <Route path="/" exact component={Home} />
            <Route path="/createpost" exact component={CreatePost} />
            <Route path="/post/:id" exact component={Post} />
            <Route path="/registration" exact component={Registration} />
            <Route path="/login" exact component={Login} />
            <Route path="*" exact component={PageNotFound} />
          </Switch>
        </Router>
      </AuthContext.Provider>
      <div style={myStyle}>
      </div>
    </div>
  );
}

export default App;

module.exports = (sequelize, DataTypes) => {
  const Applied = sequelize.define("Applied");

  return Applied;
};
